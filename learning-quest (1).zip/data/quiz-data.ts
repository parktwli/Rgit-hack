export const quizQuestions = [
  {
    question: "What does HTML stand for?",
    answers: [
      "Hyper Text Markup Language",
      "High Tech Modern Language",
      "Hyperlink and Text Markup Language",
      "Home Tool Markup Language",
    ],
    correctAnswer: 0,
  },
  {
    question: "Which of the following is used to style web pages?",
    answers: ["JavaScript", "HTML", "CSS", "PHP"],
    correctAnswer: 2,
  },
  {
    question: "Which programming language is primarily used for adding interactivity to websites?",
    answers: ["Java", "Python", "C++", "JavaScript"],
    correctAnswer: 3,
  },
  {
    question: "What does CSS stand for?",
    answers: ["Creative Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Colorful Style Sheets"],
    correctAnswer: 1,
  },
  {
    question: "Which HTML tag is used to create a hyperlink?",
    answers: ["<link>", "<a>", "<href>", "<url>"],
    correctAnswer: 1,
  },
]

