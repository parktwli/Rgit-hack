import type React from "react"
import { BookOpen, Code, Layout } from "lucide-react"

export type Quest = {
  id: string
  title: string
  description: string
  xpReward: number
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  status: "available" | "locked" | "completed"
  requiredLevel?: number
  icon: React.ElementType
  slug: string
}

export const quests: Quest[] = [
  {
    id: "web_fundamentals",
    title: "Web Development Fundamentals",
    description: "Learn the basics of HTML, CSS, and JavaScript",
    xpReward: 50,
    difficulty: "Beginner",
    status: "completed",
    icon: BookOpen,
    slug: "web-fundamentals",
  },
  {
    id: "js_fundamentals",
    title: "JavaScript Fundamentals",
    description: "Master the basics of JavaScript programming",
    xpReward: 100,
    difficulty: "Beginner",
    status: "available",
    icon: Code,
    slug: "javascript-fundamentals",
  },
  {
    id: "responsive_design",
    title: "Responsive Design Challenge",
    description: "Create layouts that work on any device",
    xpReward: 90,
    difficulty: "Intermediate",
    status: "available",
    icon: Layout,
    slug: "responsive-design",
  },
  {
    id: "css_animations",
    title: "CSS Animation Mastery",
    description: "Learn advanced CSS animations and transitions",
    xpReward: 75,
    difficulty: "Intermediate",
    status: "locked",
    requiredLevel: 2,
    icon: Code,
    slug: "css-animations",
  },
]

// JavaScript Fundamentals Quest Content
export const jsQuestContent = {
  introduction: {
    title: "JavaScript Fundamentals",
    description:
      "JavaScript is the programming language of the web. It allows you to add dynamic behavior, store information, and handle requests and responses on a website. In this quest, you'll learn the core concepts of JavaScript that every web developer should know.",
  },
  sections: [
    {
      title: "Variables and Data Types",
      content:
        "JavaScript has several data types: strings, numbers, booleans, null, undefined, objects, and symbols. Variables are declared using let, const, or var (though var is now less commonly used).\n\nExample:\n```javascript\nlet name = 'John'; // String\nconst age = 30; // Number\nlet isActive = true; // Boolean\n```",
    },
    {
      title: "Functions",
      content:
        "Functions are reusable blocks of code that perform a specific task. They can take parameters and return values.\n\nExample:\n```javascript\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconst greeting = greet('World'); // Returns: Hello, World!\n```",
    },
    {
      title: "Arrays and Objects",
      content:
        "Arrays store ordered collections, while objects store keyed collections.\n\nExample:\n```javascript\n// Array\nconst fruits = ['apple', 'banana', 'orange'];\n\n// Object\nconst person = {\n  name: 'John',\n  age: 30,\n  isActive: true\n};\n```",
    },
  ],
  quiz: [
    {
      question: "Which keyword is used to declare a constant variable in JavaScript?",
      answers: ["let", "var", "const", "function"],
      correctAnswer: 2,
    },
    {
      question: "What will the following code return: typeof []?",
      answers: ["array", "object", "undefined", "null"],
      correctAnswer: 1,
    },
    {
      question: "Which method is used to add an element to the end of an array?",
      answers: ["push()", "pop()", "shift()", "unshift()"],
      correctAnswer: 0,
    },
    {
      question: "What is the correct way to write a function in JavaScript?",
      answers: [
        "function = myFunction() {}",
        "function:myFunction() {}",
        "function myFunction() {}",
        "myFunction = function() {}",
      ],
      correctAnswer: 2,
    },
    {
      question: "How do you access the first element of an array named 'fruits'?",
      answers: ["fruits(0)", "fruits.first", "fruits[0]", "fruits.0"],
      correctAnswer: 2,
    },
  ],
  badge: "code_wizard",
}

// Responsive Design Challenge Quest Content
export const responsiveQuestContent = {
  introduction: {
    title: "Responsive Design Challenge",
    description:
      "Responsive web design ensures that your website looks and functions well on all devices, from desktop computers to mobile phones. In this quest, you'll learn the principles of responsive design and how to implement them using CSS.",
  },
  sections: [
    {
      title: "Viewport and Media Queries",
      content:
        'The viewport meta tag ensures proper scaling on mobile devices. Media queries allow you to apply different styles based on device characteristics.\n\nExample:\n```html\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n```\n\n```css\n/* Styles for screens smaller than 768px */\n@media (max-width: 768px) {\n  .container {\n    width: 100%;\n  }\n}\n```',
    },
    {
      title: "Flexible Layouts",
      content:
        "Use relative units like percentages, em, rem, and viewport units instead of fixed pixels. Flexbox and Grid are powerful tools for creating flexible layouts.\n\nExample:\n```css\n.container {\n  display: flex;\n  flex-wrap: wrap;\n}\n\n.item {\n  flex: 1 1 300px; /* Grow, shrink, basis */\n  margin: 10px;\n}\n```",
    },
    {
      title: "Responsive Images",
      content:
        'Images should scale with their container and adapt to different screen sizes.\n\nExample:\n```css\nimg {\n  max-width: 100%;\n  height: auto;\n}\n```\n\nFor more advanced cases, use the picture element or srcset attribute:\n```html\n<picture>\n  <source media="(max-width: 600px)" srcset="small-image.jpg">\n  <source media="(max-width: 1200px)" srcset="medium-image.jpg">\n  <img src="large-image.jpg" alt="Responsive image">\n</picture>\n```',
    },
  ],
  quiz: [
    {
      question: "What CSS property is used to make an element's width adjust to its parent container?",
      answers: ["width: auto;", "width: 100%;", "width: fit-content;", "width: inherit;"],
      correctAnswer: 1,
    },
    {
      question: "Which CSS layout module is specifically designed for two-dimensional layouts?",
      answers: ["Flexbox", "Grid", "Float", "Position"],
      correctAnswer: 1,
    },
    {
      question: "What is the purpose of the viewport meta tag?",
      answers: [
        "To set the background color of the viewport",
        "To control the width and scaling of the viewport",
        "To hide the viewport on mobile devices",
        "To increase the font size on mobile devices",
      ],
      correctAnswer: 1,
    },
    {
      question: "Which CSS unit is relative to the font-size of the root element?",
      answers: ["px", "em", "rem", "vh"],
      correctAnswer: 2,
    },
    {
      question: "What is a breakpoint in responsive design?",
      answers: [
        "A point where the website stops working",
        "A specific viewport width where the layout changes",
        "A bug in the CSS code",
        "The maximum width a website can have",
      ],
      correctAnswer: 1,
    },
  ],
  badge: "responsive_master",
}

