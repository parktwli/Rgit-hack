import { Award, BookOpen, Code, Layout, Trophy, Zap } from "lucide-react"

export const badgeData = [
  {
    id: "quiz_master",
    name: "Quiz Master",
    description: "Successfully completed your first quiz challenge",
    icon: <Trophy className="h-5 w-5 text-amber-500" />,
  },
  {
    id: "fast_learner",
    name: "Fast Learner",
    description: "Completed a quest in record time",
    icon: <Zap className="h-5 w-5 text-yellow-500" />,
  },
  {
    id: "code_wizard",
    name: "Code Wizard",
    description: "Mastered JavaScript fundamentals",
    icon: <Code className="h-5 w-5 text-indigo-500" />,
  },
  {
    id: "responsive_master",
    name: "Responsive Master",
    description: "Mastered responsive design techniques",
    icon: <Layout className="h-5 w-5 text-blue-500" />,
  },
  {
    id: "knowledge_seeker",
    name: "Knowledge Seeker",
    description: "Completed 5 different quests",
    icon: <BookOpen className="h-5 w-5 text-emerald-500" />,
  },
  {
    id: "grand_master",
    name: "Grand Master",
    description: "Reached level 10 in your learning journey",
    icon: <Award className="h-5 w-5 text-rose-500" />,
  },
]

