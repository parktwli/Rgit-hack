"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"

type User = {
  xp: number
  badges: string[]
  quests: string[]
}

type QuestContextType = {
  user: User
  initializeUser: () => void
  addXp: (amount: number) => void
  awardBadge: (badgeId: string) => void
  completeQuest: (questId: string) => void
}

const defaultUser: User = {
  xp: 0,
  badges: [],
  quests: [],
}

const QuestContext = createContext<QuestContextType | undefined>(undefined)

export function QuestProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(defaultUser)
  const [isInitialized, setIsInitialized] = useState(false)

  // Load user data from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("quest_user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsInitialized(true)
  }, [])

  // Save user data to localStorage whenever it changes
  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem("quest_user", JSON.stringify(user))
    }
  }, [user, isInitialized])

  // Initialize a new user
  const initializeUser = () => {
    // Only initialize if user has no XP (new user)
    if (user.xp === 0) {
      setUser({
        xp: 0,
        badges: [],
        quests: [],
      })
    }
  }

  // Add XP to user
  const addXp = (amount: number) => {
    setUser((prev) => ({
      ...prev,
      xp: prev.xp + amount,
    }))
  }

  // Award a badge to user
  const awardBadge = (badgeId: string) => {
    if (!user.badges.includes(badgeId)) {
      setUser((prev) => ({
        ...prev,
        badges: [...prev.badges, badgeId],
      }))
    }
  }

  // Mark a quest as completed
  const completeQuest = (questId: string) => {
    if (!user.quests.includes(questId)) {
      setUser((prev) => ({
        ...prev,
        quests: [...prev.quests, questId],
      }))
    }
  }

  return (
    <QuestContext.Provider
      value={{
        user,
        initializeUser,
        addXp,
        awardBadge,
        completeQuest,
      }}
    >
      {children}
    </QuestContext.Provider>
  )
}

export function useQuest() {
  const context = useContext(QuestContext)
  if (context === undefined) {
    throw new Error("useQuest must be used within a QuestProvider")
  }
  return context
}

