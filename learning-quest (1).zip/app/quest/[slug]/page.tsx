"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { CheckCircle, ChevronRight, HelpCircle, Timer, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { useQuest } from "@/context/quest-context"
import { Navigation } from "@/components/navigation"
import { jsQuestContent, responsiveQuestContent } from "@/data/quest-data"

export default function QuestPage() {
  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const { user, addXp, awardBadge, completeQuest } = useQuest()
  const [currentStep, setCurrentStep] = useState(0)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [isAnswerCorrect, setIsAnswerCorrect] = useState<boolean | null>(null)
  const [timeLeft, setTimeLeft] = useState(30)
  const [isTimerActive, setIsTimerActive] = useState(false)
  const [questProgress, setQuestProgress] = useState(0)
  const [questContent, setQuestContent] = useState<any>(null)
  const [questId, setQuestId] = useState<string>("")

  // Steps in the quest
  const steps = ["introduction", "content", "quiz", "completion"]
  const totalSteps = steps.length

  useEffect(() => {
    // Determine which quest content to load based on the slug
    const slug = params?.slug as string

    if (slug === "javascript-fundamentals") {
      setQuestContent(jsQuestContent)
      setQuestId("js_fundamentals")
    } else if (slug === "responsive-design") {
      setQuestContent(responsiveQuestContent)
      setQuestId("responsive_design")
    } else if (slug === "web-fundamentals") {
      // Redirect to dashboard if trying to access completed quest
      if (user.quests.includes("web_fundamentals")) {
        router.push("/dashboard")
      }
    } else {
      // Redirect to dashboard if slug doesn't match any quest
      router.push("/dashboard")
    }
  }, [params, router, user.quests])

  useEffect(() => {
    // Update progress based on current step
    setQuestProgress(((currentStep + 1) / totalSteps) * 100)
  }, [currentStep, totalSteps])

  useEffect(() => {
    // Timer for quiz questions
    let timer: NodeJS.Timeout

    if (currentStep === 2 && isTimerActive) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            setIsTimerActive(false)
            handleAnswer(-1) // Time's up, count as wrong answer
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }

    return () => clearInterval(timer)
  }, [currentStep, isTimerActive])

  const startQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setIsAnswerCorrect(null)
    setTimeLeft(30)
    setIsTimerActive(true)
  }

  const handleAnswer = (answerIndex: number) => {
    setIsTimerActive(false)
    setSelectedAnswer(answerIndex)

    if (!questContent) return

    const currentQuiz = questContent.quiz[currentQuestion]
    const isCorrect = answerIndex === currentQuiz.correctAnswer
    setIsAnswerCorrect(isCorrect)

    if (isCorrect) {
      addXp(10)
      toast({
        title: "Correct Answer!",
        description: "You earned 10 XP",
        variant: "success",
      })
    }
  }

  const nextQuestion = () => {
    if (!questContent) return

    if (currentQuestion < questContent.quiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setIsAnswerCorrect(null)
      setTimeLeft(30)
      setIsTimerActive(true)
    } else {
      // Quiz completed
      awardBadge(questContent.badge)
      toast({
        title: "Badge Unlocked!",
        description: `You've earned the ${questContent.badge === "code_wizard" ? "Code Wizard" : "Responsive Master"} badge!`,
        variant: "success",
      })
      nextStep()
    }
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)

      if (steps[currentStep + 1] === "quiz") {
        startQuiz()
      }
    } else {
      // Quest completed
      if (questId) {
        completeQuest(questId)
        addXp(questId === "js_fundamentals" ? 100 : 90)
        toast({
          title: "Quest Complete!",
          description: `You've earned ${questId === "js_fundamentals" ? 100 : 90} XP!`,
          variant: "success",
        })
      }
      router.push("/dashboard")
    }
  }

  if (!questContent) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto flex h-[80vh] items-center justify-center">
          <div className="animate-pulse text-2xl font-bold">Loading Quest...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-lg font-medium">{questContent.introduction.title} Progress</h2>
            <span className="text-sm text-muted-foreground">{Math.round(questProgress)}%</span>
          </div>
          <Progress value={questProgress} className="h-2" />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={steps[currentStep]}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="mx-auto max-w-3xl rounded-xl border border-border bg-card p-6 shadow-lg"
          >
            {steps[currentStep] === "introduction" && (
              <IntroductionStep
                title={questContent.introduction.title}
                description={questContent.introduction.description}
                onContinue={nextStep}
              />
            )}

            {steps[currentStep] === "content" && <ContentStep sections={questContent.sections} onContinue={nextStep} />}

            {steps[currentStep] === "quiz" && questContent.quiz && (
              <QuizStep
                question={questContent.quiz[currentQuestion]}
                selectedAnswer={selectedAnswer}
                isAnswerCorrect={isAnswerCorrect}
                timeLeft={timeLeft}
                onSelectAnswer={handleAnswer}
                onNextQuestion={nextQuestion}
              />
            )}

            {steps[currentStep] === "completion" && (
              <CompletionStep title={questContent.introduction.title} onContinue={() => router.push("/dashboard")} />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  )
}

function IntroductionStep({
  title,
  description,
  onContinue,
}: {
  title: string
  description: string
  onContinue: () => void
}) {
  return (
    <div className="flex flex-col items-center text-center">
      <h1 className="mb-6 text-3xl font-bold">Welcome to {title}</h1>
      <p className="mb-8 text-lg text-muted-foreground">{description}</p>
      <Button onClick={onContinue} size="lg" className="group">
        Begin Learning
        <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
      </Button>
    </div>
  )
}

function ContentStep({
  sections,
  onContinue,
}: {
  sections: Array<{ title: string; content: string }>
  onContinue: () => void
}) {
  return (
    <div className="space-y-6">
      {sections.map((section, index) => (
        <div key={index} className="space-y-4">
          <h3 className="text-xl font-semibold">{section.title}</h3>
          <div className="text-muted-foreground whitespace-pre-line">
            {section.content.split("```").map((part, i) => {
              // If it's an even index, it's regular text
              if (i % 2 === 0) {
                return (
                  <p key={i} className="mb-4">
                    {part}
                  </p>
                )
              }
              // If it's an odd index, it's code
              else {
                const [language, ...codeParts] = part.split("\n")
                const code = codeParts.join("\n")
                return (
                  <div key={i} className="rounded-md bg-muted p-4 my-4 overflow-x-auto">
                    <pre className="text-sm font-mono">{code}</pre>
                  </div>
                )
              }
            })}
          </div>
        </div>
      ))}

      <div className="mt-8 flex justify-center">
        <Button onClick={onContinue} size="lg" className="group">
          Continue to Quiz
          <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </div>
    </div>
  )
}

function QuizStep({
  question,
  selectedAnswer,
  isAnswerCorrect,
  timeLeft,
  onSelectAnswer,
  onNextQuestion,
}: {
  question: any
  selectedAnswer: number | null
  isAnswerCorrect: boolean | null
  timeLeft: number
  onSelectAnswer: (index: number) => void
  onNextQuestion: () => void
}) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Quiz Challenge</h2>

        {selectedAnswer === null && (
          <div className="flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary">
            <Timer className="h-4 w-4" />
            <span>{timeLeft} seconds</span>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-border bg-card/50 p-4">
        <h3 className="mb-4 text-xl font-medium">{question.question}</h3>

        <div className="space-y-3">
          {question.answers.map((answer: string, index: number) => (
            <motion.button
              key={index}
              whileHover={{ scale: selectedAnswer !== null ? 1 : 1.02 }}
              whileTap={{ scale: selectedAnswer !== null ? 1 : 0.98 }}
              onClick={() => selectedAnswer === null && onSelectAnswer(index)}
              disabled={selectedAnswer !== null}
              className={`w-full rounded-lg border border-border p-3 text-left transition-colors ${
                selectedAnswer === index
                  ? isAnswerCorrect
                    ? "border-green-500 bg-green-500/10 text-green-500"
                    : "border-red-500 bg-red-500/10 text-red-500"
                  : selectedAnswer !== null && index === question.correctAnswer
                    ? "border-green-500 bg-green-500/10 text-green-500"
                    : "hover:border-primary/50 hover:bg-primary/5"
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{answer}</span>
                {selectedAnswer === index &&
                  (isAnswerCorrect ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  ))}
                {selectedAnswer !== null && index === question.correctAnswer && selectedAnswer !== index && (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {selectedAnswer !== null && (
        <div className="flex justify-center">
          <Button onClick={onNextQuestion} size="lg" className="group">
            {isAnswerCorrect ? "Correct!" : "Try Again!"} Continue
            <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>
      )}

      {selectedAnswer === null && timeLeft === 0 && (
        <div className="rounded-lg border border-yellow-500 bg-yellow-500/10 p-4 text-center text-yellow-500">
          <div className="flex items-center justify-center gap-2">
            <HelpCircle className="h-5 w-5" />
            <span className="font-medium">Time's up! The correct answer is highlighted.</span>
          </div>
          <Button onClick={onNextQuestion} variant="outline" className="mt-4">
            Continue
          </Button>
        </div>
      )}
    </div>
  )
}

function CompletionStep({
  title,
  onContinue,
}: {
  title: string
  onContinue: () => void
}) {
  return (
    <div className="flex flex-col items-center text-center">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 15 }}
        className="mb-6 rounded-full bg-primary/20 p-4"
      >
        <CheckCircle className="h-16 w-16 text-primary" />
      </motion.div>

      <h1 className="mb-4 text-3xl font-bold">Quest Completed!</h1>

      <p className="mb-8 text-lg text-muted-foreground">
        Congratulations! You've successfully completed the {title} quest. You've earned XP and unlocked new badges.
        Check your profile to see your progress!
      </p>

      <Button onClick={onContinue} size="lg" className="group">
        View Your Dashboard
        <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
      </Button>
    </div>
  )
}

