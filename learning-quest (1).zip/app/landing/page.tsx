"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowRight, Award, BookOpen, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useQuest } from "@/context/quest-context"
import { Navigation } from "@/components/navigation"

export default function LandingPage() {
  const router = useRouter()
  const { initializeUser } = useQuest()
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Simulate loading for animation purposes
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const handleStartQuest = () => {
    initializeUser()
    router.push("/quest")
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-b from-background to-background/80">
      <Navigation />

      {/* Animated background elements */}
      <div className="absolute inset-0 z-0">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 2 }}
          className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-primary/20 blur-3xl"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.4 }}
          transition={{ duration: 2, delay: 0.5 }}
          className="absolute top-1/2 -left-32 h-96 w-96 rounded-full bg-secondary/20 blur-3xl"
        />
      </div>

      <main className="container relative z-10 flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center px-4 py-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex max-w-3xl flex-col items-center text-center"
        >
          <div className="mb-2 inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm text-primary">
            <Sparkles className="mr-2 h-4 w-4" />
            <span>Transform Your Learning Journey</span>
          </div>

          <h1 className="mb-6 text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">
            Begin Your Learning <span className="text-primary">Quest</span>
          </h1>

          <p className="mb-8 max-w-2xl text-lg text-muted-foreground sm:text-xl">
            Embark on an interactive adventure where knowledge becomes power. Complete quests, earn XP, and unlock
            achievements as you master new skills.
          </p>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="mb-12">
            <Button
              size="lg"
              onClick={handleStartQuest}
              className="group relative overflow-hidden rounded-full px-8 py-6 text-lg font-semibold"
            >
              <span className="relative z-10 flex items-center">
                Begin Your Quest
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </span>
              <span className="absolute inset-0 z-0 bg-gradient-to-r from-primary to-primary/80 opacity-100 transition-opacity group-hover:opacity-90"></span>
            </Button>
          </motion.div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
            <FeatureCard
              icon={<BookOpen className="h-10 w-10 text-primary" />}
              title="Interactive Lessons"
              description="Engage with dynamic content that adapts to your learning style"
            />
            <FeatureCard
              icon={<Sparkles className="h-10 w-10 text-primary" />}
              title="Earn XP & Level Up"
              description="Track your progress and grow your skills with each completed quest"
            />
            <FeatureCard
              icon={<Award className="h-10 w-10 text-primary" />}
              title="Unlock Achievements"
              description="Collect badges and rewards as you master new concepts"
            />
          </div>
        </motion.div>
      </main>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="flex flex-col items-center rounded-xl border border-border bg-card p-6 text-center shadow-sm"
    >
      <div className="mb-4 rounded-full bg-primary/10 p-3">{icon}</div>
      <h3 className="mb-2 text-xl font-bold">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </motion.div>
  )
}

