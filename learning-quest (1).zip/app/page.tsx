"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function Home() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to landing page
    router.push("/landing")
  }, [router])

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Loading state while redirecting */}
      <div className="flex h-screen items-center justify-center">
        <div className="animate-pulse text-2xl font-bold">Loading Quest...</div>
      </div>
    </div>
  )
}

