import type React from "react"
import { QuestProvider } from "@/context/quest-context"
import { ThemeProvider } from "@/components/theme-provider"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "v0 App",
  description: "Created with v0",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <QuestProvider>{children}</QuestProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'