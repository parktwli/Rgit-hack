"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Award, BookOpen, ChevronRight, Clock, Star, Trophy, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useQuest } from "@/context/quest-context"
import { Navigation } from "@/components/navigation"
import { badgeData } from "@/data/badge-data"
import { quests } from "@/data/quest-data"

export default function DashboardPage() {
  const router = useRouter()
  const { user, completeQuest } = useQuest()
  const [mounted, setMounted] = useState(false)

  // Calculate level and progress
  const level = Math.floor(user.xp / 100) + 1
  const levelProgress = user.xp % 100
  const xpToNextLevel = 100 - levelProgress

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const handleStartQuest = (questSlug: string) => {
    router.push(`/quest/${questSlug}`)
  }

  // Update quest status based on completed quests
  const availableQuests = quests.map((quest) => {
    if (user.quests.includes(quest.id)) {
      return { ...quest, status: "completed" as const }
    }
    if (quest.requiredLevel && level < quest.requiredLevel) {
      return { ...quest, status: "locked" as const }
    }
    return { ...quest, status: "available" as const }
  })

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
          <h1 className="text-3xl font-bold">Hero Dashboard</h1>
          <Button variant="outline" className="group" onClick={() => router.push("/quest")}>
            Start New Quest
            <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="col-span-3 rounded-xl border border-border bg-card p-6 shadow-sm md:col-span-2"
          >
            <div className="mb-6 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">Hero Profile</h2>
                  <p className="text-sm text-muted-foreground">Your learning journey stats</p>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 font-medium text-primary">
                <Star className="h-5 w-5" />
                <span>Level {level} Hero</span>
              </div>
            </div>

            <div className="mb-6 grid gap-6 sm:grid-cols-3">
              <StatCard
                icon={<Trophy className="h-5 w-5 text-amber-500" />}
                label="Total XP"
                value={user.xp}
                bgColor="bg-amber-500/10"
                textColor="text-amber-500"
              />

              <StatCard
                icon={<Award className="h-5 w-5 text-indigo-500" />}
                label="Badges Earned"
                value={user.badges.length}
                bgColor="bg-indigo-500/10"
                textColor="text-indigo-500"
              />

              <StatCard
                icon={<BookOpen className="h-5 w-5 text-emerald-500" />}
                label="Quests Completed"
                value={user.quests.length}
                bgColor="bg-emerald-500/10"
                textColor="text-emerald-500"
              />
            </div>

            <div className="mb-6">
              <div className="mb-2 flex items-center justify-between">
                <h3 className="font-medium">Level Progress</h3>
                <span className="text-sm text-muted-foreground">{levelProgress}%</span>
              </div>
              <Progress value={levelProgress} className="h-2" />
              <p className="mt-2 text-sm text-muted-foreground">
                {xpToNextLevel} XP needed for Level {level + 1}
              </p>
            </div>

            <div className="rounded-lg border border-border bg-card/50 p-4">
              <h3 className="mb-4 font-medium">Recent Activity</h3>
              <div className="space-y-3">
                {user.quests.length > 0 ? (
                  user.quests.map((questId, index) => {
                    const quest = quests.find((q) => q.id === questId)
                    if (!quest) return null

                    return (
                      <ActivityItem
                        key={questId}
                        icon={<BookOpen className="h-5 w-5" />}
                        title={`Completed ${quest.title}`}
                        time={index === 0 ? "Just now" : "Recently"}
                        xp={`+${quest.xpReward} XP`}
                      />
                    )
                  })
                ) : (
                  <div className="rounded-lg border border-dashed border-border p-6 text-center">
                    <p className="text-muted-foreground">Complete quests to see your activity!</p>
                  </div>
                )}

                {user.badges.length > 0 && (
                  <ActivityItem
                    icon={<Award className="h-5 w-5" />}
                    title={`Earned ${user.badges.length} Badge${user.badges.length > 1 ? "s" : ""}`}
                    time="Recently"
                    xp="+20 XP"
                  />
                )}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="col-span-3 rounded-xl border border-border bg-card p-6 shadow-sm md:col-span-1"
          >
            <h2 className="mb-4 text-xl font-bold">Your Badges</h2>

            <Tabs defaultValue="earned">
              <TabsList className="mb-4 grid w-full grid-cols-2">
                <TabsTrigger value="earned">Earned</TabsTrigger>
                <TabsTrigger value="available">Available</TabsTrigger>
              </TabsList>

              <TabsContent value="earned" className="space-y-4">
                {user.badges.length > 0 ? (
                  user.badges.map((badgeId) => {
                    const badge = badgeData.find((b) => b.id === badgeId)
                    if (!badge) return null

                    return (
                      <BadgeCard
                        key={badge.id}
                        name={badge.name}
                        description={badge.description}
                        icon={badge.icon}
                        earned={true}
                      />
                    )
                  })
                ) : (
                  <div className="rounded-lg border border-dashed border-border p-6 text-center">
                    <p className="text-muted-foreground">Complete quests to earn badges!</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="available" className="space-y-4">
                {badgeData
                  .filter((badge) => !user.badges.includes(badge.id))
                  .map((badge) => (
                    <BadgeCard
                      key={badge.id}
                      name={badge.name}
                      description={badge.description}
                      icon={badge.icon}
                      earned={false}
                    />
                  ))}
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="mt-6 rounded-xl border border-border bg-card p-6 shadow-sm"
        >
          <h2 className="mb-6 text-xl font-bold">Available Quests</h2>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {availableQuests.map((quest) => (
              <QuestCard
                key={quest.id}
                title={quest.title}
                description={quest.description}
                xpReward={quest.xpReward}
                difficulty={quest.difficulty}
                status={quest.status}
                requiredLevel={quest.requiredLevel}
                onStart={() => handleStartQuest(quest.slug)}
              />
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  )
}

function StatCard({
  icon,
  label,
  value,
  bgColor,
  textColor,
}: {
  icon: React.ReactNode
  label: string
  value: number
  bgColor: string
  textColor: string
}) {
  return (
    <div className="rounded-lg border border-border bg-card/50 p-4">
      <div className="mb-2 flex items-center gap-2">
        <div className={`rounded-full ${bgColor} p-1.5`}>{icon}</div>
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <p className={`text-2xl font-bold ${textColor}`}>{value}</p>
    </div>
  )
}

function ActivityItem({
  icon,
  title,
  time,
  xp,
}: {
  icon: React.ReactNode
  title: string
  time: string
  xp: string
}) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-border bg-card/30 p-3">
      <div className="flex items-center gap-3">
        <div className="rounded-full bg-primary/10 p-2">{icon}</div>
        <div>
          <p className="font-medium">{title}</p>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="h-3 w-3" /> {time}
          </p>
        </div>
      </div>
      <span className="text-sm font-medium text-emerald-500">{xp}</span>
    </div>
  )
}

function BadgeCard({
  name,
  description,
  icon,
  earned,
}: {
  name: string
  description: string
  icon: React.ReactNode
  earned: boolean
}) {
  return (
    <div className={`rounded-lg border ${earned ? "border-primary/30 bg-primary/5" : "border-border bg-card/50"} p-4`}>
      <div className="flex items-start gap-3">
        <div className={`rounded-full ${earned ? "bg-primary/20" : "bg-muted"} p-2`}>{icon}</div>
        <div>
          <h3 className="font-medium">{name}</h3>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  )
}

function QuestCard({
  title,
  description,
  xpReward,
  difficulty,
  status,
  requiredLevel,
  onStart,
}: {
  title: string
  description: string
  xpReward: number
  difficulty: string
  status: "available" | "locked" | "completed"
  requiredLevel?: number
  onStart: () => void
}) {
  return (
    <div
      className={`relative rounded-xl border ${
        status === "available"
          ? "border-border"
          : status === "completed"
            ? "border-green-500/30 bg-green-500/5"
            : "border-border bg-card/50 opacity-80"
      } p-5`}
    >
      {status === "locked" && requiredLevel && (
        <div className="absolute inset-0 flex items-center justify-center rounded-xl backdrop-blur-[1px]">
          <div className="rounded-lg bg-background/90 p-3 text-center shadow-lg">
            <p className="text-sm font-medium">Unlocks at Level {requiredLevel}</p>
          </div>
        </div>
      )}

      <h3 className="mb-2 text-lg font-bold">{title}</h3>
      <p className="mb-4 text-sm text-muted-foreground">{description}</p>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          <Trophy className="h-3.5 w-3.5" />
          <span>+{xpReward} XP</span>
        </div>

        <span className="text-xs text-muted-foreground">{difficulty}</span>
      </div>

      {status === "available" && (
        <Button className="mt-4 w-full" size="sm" onClick={onStart}>
          Start Quest
        </Button>
      )}

      {status === "completed" && (
        <Button className="mt-4 w-full" size="sm" variant="outline" onClick={onStart}>
          Review Quest
        </Button>
      )}
    </div>
  )
}

